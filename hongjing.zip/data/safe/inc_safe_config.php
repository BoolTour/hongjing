<?php
$safe_gdopen = '1,2,3,4,5,6,7';
$safe_codetype = '3';
$safe_gdtype = '1';
$safe_gdstyle = '3';
$safe_wwidth = '68';
$safe_wheight = '24';
$safe_codelen = '4';
$safe_faq_reg = '0';
$safe_faq_send = '0';
$safe_faq_msg = '1';
$safe_faqs = 'a:4:{i:1;a:2:{s:8:"question";s:37:"您最喜欢的网建程序是什么?";s:6:"answer";s:7:"DedeCMS";}i:2;a:2:{s:8:"question";s:6:"1+11=?";s:6:"answer";s:2:"12";}i:3;a:2:{s:8:"question";s:59:"中国哪项体育运动最让人听着伤心,看着揪心?";s:6:"answer";s:6:"足球";}i:4;a:2:{s:8:"question";s:29:"<img src="/images/dede.gif"/>";s:6:"answer";s:24:"织梦内容管理系统";}}';

?>

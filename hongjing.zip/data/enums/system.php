<?php
global $em_systems;
$em_systems = array();
$em_systems['0'] = '仅用于判断缓存是否存在';
?>
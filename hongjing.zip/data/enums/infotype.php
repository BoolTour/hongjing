<?php
global $em_infotypes;
$em_infotypes = array();
$em_infotypes['500'] = '商品';
$em_infotypes['501'] = '出售';
$em_infotypes['502'] = '求购';
$em_infotypes['503'] = '交换';
$em_infotypes['504'] = '合作';
$em_infotypes['1000'] = '租房';
$em_infotypes['1001'] = '出租';
$em_infotypes['1002'] = '求租';
$em_infotypes['1003'] = '合租';
$em_infotypes['1500'] = '交友';
$em_infotypes['1501'] = '找帅哥';
$em_infotypes['1502'] = '找美女';
$em_infotypes['1503'] = '纯友谊';
$em_infotypes['1504'] = '玩伴';
$em_infotypes['2000'] = '招聘';
$em_infotypes['2500'] = '求职';
$em_infotypes['2501'] = '水货';
$em_infotypes['2501.001'] = '水111';
$em_infotypes['2501.002'] = '水222';
$em_infotypes['2502'] = '有才';
$em_infotypes['2502.001'] = '有才啊啊啊';
$em_infotypes['3000'] = '票务';
$em_infotypes['3500'] = '服务';
$em_infotypes['4000'] = '培训';
?>